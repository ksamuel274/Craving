//
//  CellCategory.swift
//  FoodApp
//
//  Created by Panagiota on 1/12/21.
//

import UIKit

class CellCategory: UITableViewCell {

    
    @IBOutlet var CategoryLabel: UILabel!
    
}
